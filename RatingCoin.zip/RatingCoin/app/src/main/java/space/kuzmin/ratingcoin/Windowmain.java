package space.kuzmin.ratingcoin;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Windowmain extends AppCompatActivity {
  private ImageButton imgbnt,imgbtn1, imgbutton;
  @Override
  protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.windowmain);

    imgbnt =(ImageButton)findViewById(R.id.userprofile);
    imgbnt.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        try {
          Intent i = new Intent(Windowmain.this,ProfileUser.class);
          startActivity(i);
          finish();
        }catch (Exception e){
          //No code
        }
      }
    });

    imgbtn1 = (ImageButton)findViewById(R.id.menulist);
    imgbtn1.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        try {
          Intent i = new Intent(Windowmain.this,MenuWindow.class);
          startActivity(i);
          finish();
        }catch (Exception e){
          //No code
        }
      }
    });

    imgbutton = (ImageButton)findViewById(R.id.question);
    imgbutton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        try {
          Intent i = new Intent(Windowmain.this,Helplayout.class);
          startActivity(i);
          finish();
        }catch (Exception e){

        }
      }
    });

    ImageButton button_op = (ImageButton)findViewById(R.id.option1);
    button_op.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        try {
            Intent i = new Intent(Windowmain.this,OpitionsLayuot.class);
            startActivity(i);
            finish();
        }catch (Exception e){

        }
      }
    });

    ImageButton btn_search = (ImageButton)findViewById(R.id.search);
    btn_search.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        try {
          Intent intent = new Intent(Windowmain.this,Searchlist.class);
          startActivity(intent);
          finish();
        }catch (Exception e){
          //no code
        }
      }
    });


  }
}
