package space.kuzmin.ratingcoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Helplayout extends AppCompatActivity {
  private Button button_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_helplayout);

        button_back = (Button)findViewById(R.id.button_back3);
        button_back.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            try {
              Intent i = new Intent(Helplayout.this,Windowmain.class);
              startActivity(i);
              finish();
            }catch (Exception e){
              //NO code
            }
          }
        });
    }
}
